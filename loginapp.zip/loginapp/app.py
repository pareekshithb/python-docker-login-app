def login():
    username = input("Enter username: ")
    password = input("Enter password: ")

    if username == "pareekshith" and password == "pragma":
        print("Login successful!")
    else:
        print("Login failed!")

if __name__ == "__main__":
    login()
